from time import sleep
import os
from ev3dev2.button import Button
from time import sleep

btn = Button()
os.system('setfont Lat12-TerminusBold14')
# os.system('setfont Lat15-TerminusBold32x16')  # Try this larger font

print('[ INFO ] :: Libraries loaded')
print()
sleep(1)

def run(state):
    if state == 1:
        os.system('mc')
    if state == 2:
        os.system('htop')
    if state == 1:
        os.system('cd ../ && python3 boot.py')
    if (state == 4) or (state == 5):
        os.system('clear')
        print('Not supported!')
    if state == 6:
        os.system('cd ./snake && ./runaud.sh')

def menu(state):
    os.system('clear')
    if state == 1:
        print('> 1. Start MC')
        print('  2. Start HTOP')
        print('  3. Boot PyOs')
        print('  4. Update from server')
        print('  5. Update from github')
        print('  6. Snake!')
    if state == 2:
        print('  1. Start MC')
        print('> 2. Start HTOP')
        print('  3. Boot PyOs')
        print('  4. Update from server')
        print('  5. Update from github')
        print('  6. Snake!')
    if state == 3:
        print('  1. Start MC')
        print('  2. Start HTOP')
        print('> 3. Boot PyOs')
        print('  4. Update from server')
        print('  5. Update from github')
        print('  6. Snake!')
    if state == 4:
        print('  1. Start MC')
        print('  2. Start HTOP')
        print('  3. Boot PyOs')
        print('> 4. Update from server')
        print('  5. Update from github')
        print('  6. Snake!')
    if state == 5:
        print('  1. Start MC')
        print('  2. Start HTOP')
        print('  3. Boot PyOs')
        print('  4. Update from server')
        print('> 5. Update from github')
        print('  6. Snake!')
    if state == 6:
        print('  1. Start MC')
        print('  2. Start HTOP')
        print('  3. Boot PyOs')
        print('  4. Update from server')
        print('  5. Update from github')
        print('> 6. Snake!')

pag = 1

while True:
    menu(pag)
    if(btn.up):
        if(pag != 1):
            pag = pag-1
    if(btn.down):
        if(pag != 5):
            pag = pag+1
    if(btn.enter):
        run(pag)
    sleep(0.15)
