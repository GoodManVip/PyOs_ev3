#!/bin/bash

nodejs $(dirname "$0")/snake.js
