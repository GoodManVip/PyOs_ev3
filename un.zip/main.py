#EV3PYOS
import os
os.system('setfont Lat15-TerminusBold14')
# os.system('setfont Lat15-TerminusBold32x16')  # Try this larger font

print('[ INFO ] :: Starting PyOS v1.0')
import time
import random
from time import sleep
print('[ INFO ] :: Loaded libraries')

sleep(15)  # display the text long enough for it to be seen
